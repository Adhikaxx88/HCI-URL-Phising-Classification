import { LinkPredictor } from './LinkPredictor';

export function Home() {
  return (
    <div className="flex items-center justify-center min-h-full">
      <LinkPredictor />
    </div>
  );
}
